# HeavenX

HeavenX is an iOS emulator frontend for XCI/NSP files.

Build using GitHub Actions or Xcode on macOS.