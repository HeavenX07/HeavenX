class EmulatorCore {
    static let shared = EmulatorCore()

    func loadGame(at path: String) {
        // Load game
    }

    func start() {
        // Start emulator
    }
}